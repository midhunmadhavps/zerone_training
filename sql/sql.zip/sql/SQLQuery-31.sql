
--	Customers who ordered products of a given supplier in the last n number of months


select min(Customers.Name) as CustomerName
,min(Customers.Email) as email
,min(Products.ProductID)
,min(Suppliers.name) as Suppliername
  from Products
  join ProductSuppliers on ProductS.ProductID = ProductSuppliers.ProductID
  join Suppliers on ProductSuppliers.SupplierID = Suppliers.SupplierID
  join OrderItems on OrderItems.ProductSupplierID = ProductSuppliers.ProductSupplierID
  join Orders on Orders.OrderID = OrderItems.OrderID
  join Customers on Customers.CustomerID = Orders.CustomerID
  where  OrderDate between DATEADD("m",-3,GETDATE()) and GETDATE() and Suppliers.SupplierID = 33
  group by Customers.CustomerID