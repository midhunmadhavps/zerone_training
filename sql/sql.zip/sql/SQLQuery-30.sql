select Customers.CustomerID as customer,min(Customers.Name) as CustomerName,count(OrderId) as orders from 
Customers join Orders on Customers.CustomerID = Orders.CustomerID
where OrderDate between DATEADD("m",-6,GETDATE()) and GETDATE()
group by Customers.CustomerID
having count(OrderId)>1
order by min(Customers.Name)
