
select min(Categories.Name) as CategoryName,
Count(Products.ProductID) as ProductCount from Products 
join Categories on Products.CategoryID = Categories.CategoryID
where Status = 0
group by Categories.CategoryID
order by MIN(Categories.name)
