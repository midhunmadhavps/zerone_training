select max(Suppliers.Name) as SupplierName,max(Products.Name) as ProductName, sum(Rate * OrderItems.Quantity) as 'sale Value'
from Products 
join ProductSuppliers on Products.ProductID = ProductSuppliers.ProductSupplierID
join OrderItems on OrderItems.ProductSupplierID = ProductSuppliers.ProductSupplierID
join Suppliers on Suppliers.SupplierID = ProductSuppliers.SupplierID
join Orders on Orders.OrderID = OrderItems.OrderID

where OrderDate between DATEADD("m",-6, GETDATE()) and GETDATE() and Suppliers.SupplierID = 5

Group by Products.ProductID
