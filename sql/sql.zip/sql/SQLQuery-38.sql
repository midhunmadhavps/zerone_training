
select max(Products.Name) as ProductName,max(Orders.OrderDate) as date,avg(OrderItems.Quantity) as 'Average no Orders'
from Products 
join ProductSuppliers on Products.ProductID = ProductSuppliers.ProductID
join OrderItems on OrderItems.ProductSupplierID = ProductSuppliers.ProductSupplierID
join Orders on Orders.OrderID = OrderItems.OrderID

where OrderDate between DATEADD("m",-3, GETDATE()) and GETDATE() 
Group by Products.ProductID
--Orders.OrderDate,
