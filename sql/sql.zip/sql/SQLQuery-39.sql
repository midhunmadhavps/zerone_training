Select max(Suppliers.SupplierID) as SupplierId,
MAX(Suppliers.Name) as SuppliersName ,
max(Products.name) as ProductName,
avg(CustomerRating) as CustomerRating 
FROM OrderItems
  join Orders on OrderItems.OrderID = Orders.OrderID 
  join ProductSuppliers on OrderItems.ProductSupplierID =  ProductSuppliers.ProductSupplierID
  join Products ON ProductSuppliers.ProductID =Products.ProductID  
  join Suppliers on ProductSuppliers.SupplierID = Suppliers.SupplierID 
  join ShipmentItems on OrderItems.OrderItemID = ShipmentItems.OrderItemID
  join Shipments on ShipmentItems.ShipmentID = Shipments.ShipmentID 

where DeliveryDate between DATEADD("m",-6, GETDATE()) and GETDATE() and Suppliers.SupplierID=78

Group by Products.ProductID

