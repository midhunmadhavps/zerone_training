

alter procedure spTemptable
as
begin

	create table #ProblematicOrders(OrderItemID int,ProductName varchar(200), SupplierName varchar(200),
	CourierCompany varchar(200),OrderDate date,ShipmentDate date,DeliveryDate date,EmployeeName varchar(200),CustomerRating int)

	insert into #ProblematicOrders (OrderItemID,ProductName,SupplierName,CourierCompany,OrderDate,ShipmentDate,DeliveryDate,
	EmployeeName,CustomerRating )

	select OrderItems.OrderItemID,Products.Name,Suppliers.Name,Shipments.CourierCompany,Orders.OrderDate,
	shipments.shipmentdate,Shipments.DeliveryDate,Employees.Name,ShipmentItems.CustomerRating 
	from OrderItems 
	join Orders on OrderItems.OrderID = Orders.OrderID
	join ProductSuppliers on OrderItems.ProductSupplierID = ProductSuppliers.ProductSupplierID 
	join ShipmentItems on OrderItems.OrderItemID = ShipmentItems.OrderItemID 
	join Shipments on ShipmentItems.ShipmentID = Shipments.ShipmentID
	join Suppliers on ProductSuppliers.SupplierID = Suppliers.SupplierID
	join Products on ProductSuppliers.ProductID = Products.ProductID
	join Employees on Orders.EmployeeID = Employees.EmployeeID
	where datediff(DAY,Orders.OrderDate ,Shipments.shipmentdate) >= 3

	insert into #ProblematicOrders (OrderItemID,ProductName,SupplierName,CourierCompany,OrderDate,ShipmentDate,DeliveryDate,
	EmployeeName,CustomerRating )

	select OrderItems.OrderItemID,Products.Name,Suppliers.Name,Shipments.CourierCompany,Orders.OrderDate,
	shipments.shipmentdate,Shipments.DeliveryDate,Employees.Name,ShipmentItems.CustomerRating 
from OrderItems  
join Orders on OrderItems.OrderID = Orders.OrderID
join ProductSuppliers on OrderItems.ProductSupplierID = ProductSuppliers.ProductSupplierID 
join ShipmentItems on OrderItems.OrderItemID = ShipmentItems.OrderItemID 
join Shipments on ShipmentItems.ShipmentID = Shipments.ShipmentID
join Suppliers on ProductSuppliers.SupplierID = Suppliers.SupplierID
join Products on ProductSuppliers.ProductID = Products.ProductID
join Employees on Orders.EmployeeID = Employees.EmployeeID
where datediff(DAY,Orders.OrderDate ,Shipments.DeliveryDate) >= 10

	insert into #ProblematicOrders (OrderItemID,ProductName,SupplierName,CourierCompany,OrderDate,ShipmentDate,DeliveryDate,
	EmployeeName,CustomerRating )

	select OrderItems.OrderItemID,Products.Name,Suppliers.Name,Shipments.CourierCompany,Orders.OrderDate,
	shipments.shipmentdate,Shipments.DeliveryDate,Employees.Name,ShipmentItems.CustomerRating 
	from OrderItems 
	join Orders on OrderItems.OrderID = Orders.OrderID
	join ProductSuppliers on OrderItems.ProductSupplierID = ProductSuppliers.ProductSupplierID 
	join ShipmentItems on OrderItems.OrderItemID = ShipmentItems.OrderItemID 
	join Shipments on ShipmentItems.ShipmentID = Shipments.ShipmentID
	join Suppliers on ProductSuppliers.SupplierID = Suppliers.SupplierID
	join Products on ProductSuppliers.ProductID = Products.ProductID
	join Employees on Orders.EmployeeID = Employees.EmployeeID
	where CustomerRating <= 3

	insert into #ProblematicOrders (OrderItemID,ProductName,SupplierName,CourierCompany,OrderDate,ShipmentDate,DeliveryDate,
	EmployeeName,CustomerRating )

	select OrderItems.OrderItemID,Products.Name,Suppliers.Name,Shipments.CourierCompany,Orders.OrderDate,
	shipments.shipmentdate,Shipments.DeliveryDate,Employees.Name,ShipmentItems.CustomerRating 
from OrderItems 
join Orders on OrderItems.OrderID = Orders.OrderID
join ProductSuppliers on OrderItems.ProductSupplierID = ProductSuppliers.ProductSupplierID 
left join ShipmentItems on OrderItems.OrderItemID = ShipmentItems.OrderItemID 
left join Shipments on ShipmentItems.ShipmentID = Shipments.ShipmentID
join Suppliers on ProductSuppliers.SupplierID = Suppliers.SupplierID
join Products on ProductSuppliers.ProductID = Products.ProductID
left join Employees on Orders.EmployeeID = Employees.EmployeeID
where datediff(DAY,Orders.OrderDate ,GETDATE()) >= 3 and Orders.EmployeeID is null

	select * from #ProblematicOrders
	
end