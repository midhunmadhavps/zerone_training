
-- Create a view to find least ordered 20 items in past n months.

alter view leastOrders as

select top 20 min(Products.Name) as ProductName,sum(OrderItems.Quantity) as Quantity from ProductSuppliers 

join OrderItems on OrderItems.ProductSupplierID = ProductSuppliers.ProductSupplierID
join Orders on OrderItems.OrderID = Orders.OrderID
join Products on Products.ProductID = ProductSuppliers.ProductID

where OrderDate between DATEADD("m" , -6 , GETDATE()) and GETDATE()
group by Products.ProductID
order by Quantity asc

--select * from leastOrders

