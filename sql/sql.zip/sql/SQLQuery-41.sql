
select max(Suppliers.Name) as SuppliersName,max(Orders.OrderDate) 
as OrderDate ,avg(OrderItems.Quantity) as 'Average no Orders' 
from Orders join OrderItems on Orders.OrderID = OrderItems.OrderID join 
ProductSuppliers on ProductSuppliers.ProductSupplierID =
 OrderItems.ProductSupplierID join Suppliers on Suppliers.SupplierID = ProductSuppliers.SupplierID 
where OrderDate between DATEADD("m",-3, GETDATE()) and GETDATE() and Suppliers.SupplierID = 1 
Group by Orders.OrderDate,ProductSuppliers.ProductID
Order by Orders.orderDate