

select max(Customers.Name) as CustomerName, sum(Rate * OrderItems.Quantity) as 'sale Value'
from Products 
join ProductSuppliers on Products.ProductID = ProductSuppliers.ProductSupplierID
join OrderItems on OrderItems.ProductSupplierID = ProductSuppliers.ProductSupplierID
join Orders on Orders.OrderID = OrderItems.OrderID
join Customers on Customers.CustomerID = Orders.CustomerID

where OrderDate between DATEADD("m",-6, GETDATE()) and GETDATE() 
Group by Customers.CustomerID

