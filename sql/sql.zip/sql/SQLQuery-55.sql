

--55 Create a procedure to process shipping of an order. Take OrderID, Courier Company Name & ShipmentDate.
--Assume that all items in an order are shipped in same shipment.

create procedure spShipmentOrder
	
	@CourierCompany  Varchar(250),
	@ShipmentDate  Date, 
	@Orderid int
	
as
declare @shipmentid int
begin
begin try
	begin transaction shipmentOrder
		set nocount on

		insert into Shipments (CourierCompany,ShipmentDate)
		values(@CourierCompany,@ShipmentDate)

		set @shipmentid = IDENT_CURRENT('dbo.Shipments')
		insert into shipmentItems (ShipmentID,OrderItemID)
		select @shipmentid,OrderItemID from OrderItems where OrderID=@Orderid

	commit transaction shipmentOrder
end try

begin catch 
	rollback transaction shipmentOrder
end catch

	select OrderItems.OrderID,ShipmentItemID,ShipmentID,OrderItems.OrderItemID From ShipmentItems 
	join OrderItems on ShipmentItems.OrderItemID = OrderItems.OrderItemID
	where OrderID = 25

end

--spShipmentOrder'madhavam','2022-01-10',25 




