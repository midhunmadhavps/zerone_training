
-- 50 Supplier of the month: Create a scalar function to get the supplier id of the supplier
-- who delevered maximum order values in a given month & year

select Suppliers.SupplierID,sum(OrderItems.Quantity * Products.Rate) from OrderItems join Orders on OrderItems.OrderID = Orders.OrderID
join ProductSuppliers on ProductSuppliers.ProductSupplierID = OrderItems.ProductSupplierID
join Suppliers on Suppliers.SupplierID = ProductSuppliers.SupplierID
join Products on Products.ProductID = ProductSuppliers.ProductID
join ShipmentItems on ShipmentItems.OrderItemID = OrderItems.OrderItemID
join Shipments on Shipments.ShipmentID = ShipmentItems.ShipmentID
where month(Shipments.DeliveryDate) = 12 and year(Shipments.DeliveryDate) = 2022
group by Suppliers.SupplierID order by sum(OrderItems.Quantity * Products.Rate) desc



create function SupplierIDcalc(@Mnth int, @Yr int)
returns int
as 
begin
  DECLARE @SUPID INT;
	
			
			select top 1 @SUPID=Suppliers.SupplierID from OrderItems join Orders on OrderItems.OrderID = Orders.OrderID
			join ProductSuppliers on ProductSuppliers.ProductSupplierID = OrderItems.ProductSupplierID
			join Suppliers on Suppliers.SupplierID = ProductSuppliers.SupplierID
			join Products on Products.ProductID = ProductSuppliers.ProductID
			join ShipmentItems on ShipmentItems.OrderItemID = OrderItems.OrderItemID
			join Shipments on Shipments.ShipmentID = ShipmentItems.ShipmentID
			where month(Shipments.DeliveryDate) = @Mnth and year(Shipments.DeliveryDate) = @Yr
			group by Suppliers.SupplierID order by sum(OrderItems.Quantity * Products.Rate) desc
			
	return @SUPID
	end
	 
 

	 SELECT dbo.SupplierIDcalc(12,2022) as 'Supplier of the month' 

	