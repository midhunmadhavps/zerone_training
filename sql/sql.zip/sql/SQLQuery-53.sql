
--53 Create a stored procedure to insert a supplier into db. Should return number of rows inserted.

create procedure spinsertsuppliers
(	
	@Name  varchar(255),
	@ContactName  Varchar(255),
	@Phone  Varchar(100),
	@Email  Varchar(255),
	@GSTNumber  Varchar(15),
	@Status  varchar(255))
as
begin
set nocount on

	insert into Suppliers (
	Name,ContactName,Phone,Email ,GSTNumber ,Status)

	values(@Name,@ContactName,@Phone,@Email,@GSTNumber,@Status)	
	select @@ROWCOUNT as 'insertedrowscount'
end

--spinsertsuppliers 'midhun','midhunp',7559855451,'midhun@gmail.com',12345678,0