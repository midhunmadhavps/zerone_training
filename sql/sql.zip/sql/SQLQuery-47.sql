
-- 47 Create a function to get employees who managed a particular customer. Customer ID is the parameter.


create function Emp_manage(@Customerid int) 
Returns Table
as 
Return (select Employees.EmployeeID from Orders join Customers on Orders.CustomerID = Customers.CustomerID 
join Employees on Employees.EmployeeID = Orders.EmployeeID 
where Customers.CustomerID = @Customerid)


-- select * from Emp_manage(1)



