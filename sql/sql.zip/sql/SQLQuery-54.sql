
-- 54 Create a stored procedure to update an employee. Should return number of rows updated.

create procedure spupdateEmployee(
	
	@EmployeeID int,
	@Name  Varchar(100),
	@Phone  Varchar(20),
	@Email  Varchar(100),
	@Code  INT)
	
as
begin
set nocount on

	update Employees set Name = @Name,Phone = @Phone,Email = @Email,Code = @Code where EmployeeID = @EmployeeID 
	select @@ROWCOUNT as 'updatedrowscount'
	
end

--spupdateEmployee 50,'midhun',7559855451,'midhun@gmail.com',12345678

--select * from Employees