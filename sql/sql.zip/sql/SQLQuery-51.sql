
--51 Customers of the month: Returns all customers who ordered beyond a given amount in a given month & year.


SELECT Customers.CustomerID  from Products 
join ProductSuppliers on Products.ProductID = ProductSuppliers.ProductID
join OrderItems on ProductSuppliers.ProductSupplierID = OrderItems.ProductSupplierID
join Orders on OrderItems.OrderID = Orders.OrderID
join Customers on Orders.CustomerID = Customers.CustomerID
where  12=month(Orders.OrderDate)  and 2022=year(Orders.OrderDate)  and OrderItems.Quantity * Products.Rate>9000
group by Customers.CustomerID


create function Cus_Month(@prate float,@month int,@year int) 
Returns Table
as 
Return (SELECT Customers.CustomerID  from Products 
join ProductSuppliers on Products.ProductID = ProductSuppliers.ProductID
join OrderItems on ProductSuppliers.ProductSupplierID = OrderItems.ProductSupplierID
join Orders on OrderItems.OrderID = Orders.OrderID
join Customers on Orders.CustomerID = Customers.CustomerID
where  @month=month(Orders.OrderDate)  and @year=year(Orders.OrderDate)  and OrderItems.Quantity * Products.Rate>@prate
group by Customers.CustomerID
)

--select * from Cus_Month(9000,12,2022)