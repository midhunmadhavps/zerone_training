

 -- 49 Employee of the month: Create a scalar function to get the employee id of the employee
 --    who handled maximum number of orders in a given month & year

create FUNCTION EmployeIDcalc(@Mnth int, @Yr int)
returns int
as 
begin
  DECLARE @EMPID INT;
		
			select top 1 @EMPID=Orders.EmployeeID  from Employees join Orders on Orders.EmployeeID = Employees.EmployeeID
			where month(Orders.OrderDate) = @Mnth and year(Orders.OrderDate) = @Yr 
			group by Orders.EmployeeID
			order by COUNT(Orders.OrderID) desc 
			
	return @EMPID
	end
	 
	-- SELECT dbo.EmployeIDcalc(12,2022) as 'Customer of the month'


	 