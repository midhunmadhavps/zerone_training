
select Suppliers.SupplierID, sum(Rate * OrderItems.Quantity) as 'sale Value'
from Products 
join ProductSuppliers on Products.ProductID = ProductSuppliers.ProductSupplierID
join OrderItems on OrderItems.ProductSupplierID = ProductSuppliers.ProductSupplierID
join Suppliers on Suppliers.SupplierID = ProductSuppliers.SupplierID
join Orders on Orders.OrderID = OrderItems.OrderID

where OrderDate between DATEADD("m",-6, GETDATE()) and GETDATE() 
Group by Suppliers.SupplierID

