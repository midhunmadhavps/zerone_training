 
 -- 48 Customer of the month: Create a scalar function to get the customer id of the customer 
--who made maximum order values in a given month & year

alter FUNCTION CustomersIDcalc(@Mnth int, @Yr int)
returns int
as 
begin
  DECLARE @cusID INT;
	
			
			SELECT top 1 @cusID=Orders.CustomerID  from OrderItems join Orders on OrderItems.OrderID = Orders.OrderID
 
			join Customers on Orders.CustomerID = Customers.CustomerID 
			join ProductSuppliers on OrderItems.ProductSupplierID = ProductSuppliers.ProductSupplierID
			join Products on ProductSuppliers.ProductID = Products.ProductID where month(Orders.OrderDate) = @Mnth and year(Orders.OrderDate) = @Yr 
			group by Orders.CustomerID order by sum(OrderItems.Quantity * Products.Rate) desc
			
	return @cusID
	end
	 
 

	 --SELECT dbo. CustomersIDcalc(12,2022) as 'Customer of the month' 

	