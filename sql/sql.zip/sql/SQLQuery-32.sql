SELECT min(Employees.Name) as 'employee name'
	,count([OrderID]) as 'ordercount'
  FROM [dbo].[Orders] join Employees on Orders.EmployeeID = Employees.EmployeeID where Orders.IsClosed = 0  group by Employees.EmployeeID
  order by  count([OrderID])


